// DOM_JMTT_Controller.h - Projeto Domino - Etapa 6
// 18/08/2024 - Grupo: JMTT
// Joao Gabriel Guedes Vianna
// Matheus Giampaoli Silva
// Thomas Ki Sun Lee
// Tulio Goncalves Vieira

void jogo();
void fEmbaralhar();
void iniciarJogo();
void primeiroLance();
void alternarTurno();
void fDistribuir();
void jogar();
void comprarPeca(char jvez);
void carregamesaE(int pj);
void carregamesaD(int pj);
int contar(char jogador);
void achaIndice(char letra);
void indiceGeral();
booleano depositoVazio();
void fclear();
int contagem(char jogador);
bool temPecasJogaveis(char jogador);
void escolherLado(int pj);
int calcularIndiceGeral(char jogador, int indiceRelativo);
void verificarVencedor();
void gravaCadastro();
void recuperaCadastro();
bool testaj(int es);
bool testaPeca();
void jogadaComputador();
