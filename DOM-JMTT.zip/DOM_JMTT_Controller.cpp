// DOM_JMTT_Controller.cpp - Projeto Domino - Etapa 6
// 18/08/2024 - Grupo: JMTT
// Joao Gabriel Guedes Vianna
// Matheus Giampaoli Silva
// Thomas Ki Sun Lee
// Tulio Goncalves Vieira

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "DOM_JMTT_Controller.h"
#include "DOM_JMTT_View.cpp"

void fEmbaralhar() // funcao que embaralha as pecas de forma que nao se repitam e aleatoria
{
    srand(time(NULL));
    for (int i = 0; i < 28; i++)
    {
        int r = rand() % 28;
        pecaaux = pecas[i];
        pecas[i] = pecas[r];
        pecas[r] = pecaaux;
    }
}

void jogo() // o corpo/parte logica do jogo
{
    do
    {
        fMenuInicio();
        switch (op)
        {
        case 1:
            iniciarJogo();
            break;

        case 2:
            computadorJoga = true; // Define que o jogador 2 será o computador
            iniciarJogo();
            break;

        case 3:
            if (temJogo == 1)
            {
                system("cls");
                jogar();
            }
            else
            {
                apresentaMensagem("\nNao ha jogo a ser retornado\n\n");
            }
            break;

        case 4:
            regrasJogo();
            jogo();
            break;

        case 5:
            gravaCadastro();
            break;

        case 6:

            system("cls");
            
            recuperaCadastro();
            jogar();
            break;

        case 0:
            apresentaMensagem("\n\nSaindo do programa...");
            break;

        default:
            apresentaMensagem("\n\nOpcao invalida, tente novamente");
            jogo();
            break;
        }
    } while (op != 0);
}

void fDistribuir()
{

    for (int i = 0; i < 7; i++) // distribui as 7 primeiras pecas para o jogador 1
    {
        pecas[i].status = '1';
        p1[i] = pecas[i];
    }

    for (int i = 7; i < 14; i++) // distribui as 7 pecas apos a setima para o jogador 2
    {
        pecas[i].status = '2';
        p2[i - 7] = pecas[i];
    }
    for (int i = 14; i < 28; i++) // coloca o resto das pecas como disponiveis
    {
        pecas[i].status = 'D';
    }
}

void iniciarJogo() // funcao que inicia o jogo
{
    vitoria = 0;

    temJogo = 1;

    memset(&mesa, 0, sizeof(struct mesa)); // limpa a mesa

    fEmbaralhar();

    fDistribuir();

    primeiroLance();

    system("cls");

    quemPrimeiraJogada();

    alternarTurno();

    jogar();
}

void primeiroLance() // funcao que descobre de quem e qual e a primeira jogada
{
    int i, pj, dupla;
    pj = -1; // posição da peça encontrada
    dupla = -1;

    // pesquisa primeiramente entre as peças com lado1 = lado2
    for (i = 0; i < 14; i++)
    {
        if (pecas[i].lado1 == pecas[i].lado2)
        {
            if (pecas[i].lado1 > dupla)
            {
                dupla = pecas[i].lado1;
                pj = i;
            }
        }
    }

    // se nao encontrou, escolhe a peca com a maior soma
    if (pj == -1)
    {
        dupla = 0;
        for (i = 0; i < 14; i++)
        {
            if (pecas[i].lado1 + pecas[i].lado2 > dupla)
            {
                dupla = pecas[i].lado1 + pecas[i].lado2;
                pj = i;
            }
        }
    }

    // descobre qual o jogador que jogou essa primeira peca
    jvez = pecas[pj].status;

    // carrega a mesa com a primeira peca na posicao 0
    mesa[0].ladoE = pecas[pj].lado1;
    mesa[0].ladoD = pecas[pj].lado2;

    pecas[pj].status = 'M'; // muda o status da peca

    mesaE = mesa[0].ladoE;
    mesaD = mesa[0].ladoD;
    qtmesa = 1;
}

void alternarTurno() // funcao que troca o turno entre os jogadores
{
    if (jvez == '1')
    {
        jvez = '2';
        if (computadorJoga)
        {
            jogadaComputador(); // Chama a jogada do computador
        }
    }
    else
    {
        jvez = '1'; // Volta para o jogador 1
    }
}

void comprarPeca(char jvez)
{
    int i = 14, k = 0;
    while (pecas[i].status != 'D' && i < 28)
    {
        i++;
    }

    if (jvez == '1')
    {
        while (p1[k].status == '1')
        {
            k++;
        }
        pecas[i].status = '1';
        p1[k] = pecas[i];
    }
    else
    {
        while (p2[k].status == '2')
        {
            k++;
        }
        pecas[i].status = '2';
        p2[k] = pecas[i];
    }
}

void fclear()
{
    int ch;
    while ((ch = fgetc(stdin)) != EOF && ch != '\n')
        ;
}

void jogar()
{
    do
    {
        mostrarMesa();

        apresentaPeca(jvez);
        fMenuJogada();

        switch (jog)
        {

        case 'J':
        case 'j': // comeca a jogada

            escolherPeca(jvez);
            calcularIndiceGeral(jvez, indiceRelativo);

            if (!testaj(calcularIndiceGeral(jvez, indiceRelativo)) || !testaPeca())
            {
                system("cls");
                apresentaMensagem("\nPeca invalida, faca outra jogada\n\n");
            }
            else
            {
                escolherLado(nj);
                fclear();
                system("cls");
                jogadorJogou();
            }
            break;

        case 'C':
        case 'c': // compra uma peca se ainda existirem disponiveis

            if (!depositoVazio())
            {
                comprarPeca(jvez);
                system("cls");
                apresentaMensagem("\npeca comprada!\n\n");
            }
            else
            {
                system("cls");
                apresentaMensagem("\nNao ha mais pecas disponiveis\n\n");
            }

            break;

        case 'P':
        case 'p': // passa o turno

            if (temPecasJogaveis(jvez))
            {
                system("cls");
                apresentaMensagem("\nVoce ainda pode jogar! Escolha uma peca valida.\n\n");
            }
            else if (!depositoVazio())
            {
                system("cls");
                apresentaMensagem("\nVoce deve comprar uma peca!\n\n");
            }
            else
            {
                system("cls");
                alternarTurno();
            }

            break;

        case 'S':
        case 's': // sai do jogo e volta pro menu(pode ser desfeito)

            break;

        default:
            system("cls");
            apresentaMensagem("\n\nOpcao invalida\n");
            break;
        }
        verificarVencedor();
    } while (jog != 's' && jog != 'S');
}

booleano depositoVazio()
{
    for (int i = 0; i < 28; i++)
    {
        if (pecas[i].status == 'D')
        {
            return FALSE;
        }
    }
    return TRUE;
}

void carregamesaE(int pj)
{

    for (int i = qtmesa; i > 0; i--)
        mesa[i] = mesa[i - 1];

    if (pecas[pj].lado2 == mesaE)
    {
        mesa[0].ladoD = pecas[pj].lado2;
        mesa[0].ladoE = pecas[pj].lado1;
    }
    else
    {
        mesa[0].ladoD = pecas[pj].lado1;
        mesa[0].ladoE = pecas[pj].lado2;
    }

    mesaE = mesa[0].ladoE;
    qtmesa++;
    pecas[pj].status = 'M';
    passa = 0;
    alternarTurno();
}

// funcao que coloca uma peca escolida pelo jogador no lado direito da mesa
void carregamesaD(int pj)
{
    if (pecas[pj].lado2 == mesaD)
    {
        mesa[qtmesa].ladoD = pecas[pj].lado1;
        mesa[qtmesa].ladoE = pecas[pj].lado2;
    }
    else
    {
        mesa[qtmesa].ladoD = pecas[pj].lado2;
        mesa[qtmesa].ladoE = pecas[pj].lado1;
    }

    mesaD = mesa[qtmesa].ladoD;
    qtmesa++;
    pecas[pj].status = 'M';
    alternarTurno();
    passa = 0;
}

// funcao que conta a quantidade de pecas de um jogador
int contagem(char jogador)
{
    int c = 0;
    for (int i = 0; i < 28; i++)
    {
        if (pecas[i].status == jogador)
            c++;
    }
    return c;
}

bool temPecasJogaveis(char jogador)
{
    for (int i = 0; i < 28; i++)
    {
        if (pecas[i].status == jogador &&
            (pecas[i].lado1 == mesaE || pecas[i].lado1 == mesaD ||
             pecas[i].lado2 == mesaE || pecas[i].lado2 == mesaD))
        {
            return true;
        }
    }
    return false;
}

void escolherLado(int pj)
{
    char escolha;

    if ((pecas[pj].lado1 == mesaD || pecas[pj].lado2 == mesaD) && (pecas[pj].lado1 == mesaE || pecas[pj].lado2 == mesaE))
    {
        escolha = qualLado();

        if (escolha == 'E' || escolha == 'e')
            carregamesaE(pj);
        else
            carregamesaD(pj);
    }
    else if (pecas[pj].lado1 == mesaD || pecas[pj].lado2 == mesaD)
    {
        carregamesaD(pj);
    }
    else if (pecas[pj].lado1 == mesaE || pecas[pj].lado2 == mesaE)
    {
        carregamesaE(pj);
    }
    else
    {
        apresentaMensagem("\n\nPECA INVALIDA\n");
    }
}

int calcularIndiceGeral(char jogador, int indiceRelativo)
{
    int indiceGeral = -1; // Inicializa com -1 para caso algo dê errado
    int contagem = 0;     // Contador para comparar com o índice relativo desejado

    for (int i = 0; i < 28; i++)
    {
        // Verifica se a peça pertence ao jogador atual
        if (pecas[i].status == jogador)
        {
            // Verifica se o contador corresponde ao índice relativo
            if (contagem == indiceRelativo)
            {
                indiceGeral = i;
                nj = i; // Atribui o índice geral
            }

            contagem++; // Incrementa o contador, pois encontramos uma peça do jogador
        }
    }

    return indiceGeral;
}

void verificarVencedor()
{
    // Verifica se o jogador 1 venceu
    if (contagem('1') == 0)
    {
        system("cls");
        apresentaMensagem("\nJogador 1 venceu!\n\n");
        jog = 'S'; // Encerrar o jogo
        vitoria = 1;
        temJogo = 0;
    }
    // Verifica se o computador venceu
    else if (contagem('2') == 0 && computadorJoga)
    {
        system("cls");
        apresentaMensagem("\nComputador venceu!\n\n");
        jog = 'S'; // Encerrar o jogo
        vitoria = 1;
        temJogo = 0;
    }
    // Verifica se o jogador 2 venceu
    else if (contagem('2') == 0)
    {
        system("cls");
        apresentaMensagem("\nJogador 2 venceu!\n\n");
        jog = 'S'; // Encerrar o jogo
        vitoria = 1;
        temJogo = 0;
    }
    // Verifica se nenhum dos jogadores pode jogar e o depósito está vazio
    else if (!temPecasJogaveis('1') && !temPecasJogaveis('2') && depositoVazio())
    {
        int pecasJogador1 = contagem('1');
        int pecasJogador2 = contagem('2');

        // Jogador com menos peças vence
        if (pecasJogador1 < pecasJogador2)
        {
            apresentaMensagem("Nenhum jogador pode jogar. Jogador 1 tem menos peças e venceu!\n");
        }
        else if (pecasJogador2 < pecasJogador1)
        {
            apresentaMensagem("Nenhum jogador pode jogar. Jogador 2 tem menos peças e venceu!\n");
        }
        else
        {
            // Se ambos tiverem o mesmo número de peças, o jogo termina empatado
            apresentaMensagem("Nenhum jogador pode jogar. O jogo terminou empatado!\n");
        }
        jog = 'S'; // Encerrar o jogo
        vitoria = 1;
        temJogo = 0;
    }
}

void gravaCadastro()
{
    if (qtmesa == 0)
    {
        apresentaMensagem("\nSem jogo a ser gravado\n\n");
        return;
    }
    if (vitoria == 1)
    {
        apresentaMensagem("\nJogo terminado nao pode ser gravado\n\n");
        return;
    }
    else
    {
        int i;
        FILE *fp;
        FILE *fpm;
        FILE *fps;

        sitJogo.qtmesaJogo = qtmesa;
        sitJogo.jogadorJogo = jvez;
        sitJogo.jogadorComp = computadorJoga;
        sitJogo.mesaDJogo = mesaD;
        sitJogo.mesaEJogo = mesaE;

        if ((fp = fopen("SAVE_DOMINO", "w")) == NULL)
        {
            apresentaMensagem("\n\nO arquivo SAVE_DOMINO não pode ser aberto para cadastrar\n\n");
            return;
        }

        if ((fpm = fopen("SAVE_MESA", "w")) == NULL)
        {
            apresentaMensagem("\n\nO arquivo SAVE_MESA não pode ser aberto para cadastrar\n\n");
            return;
        }

        if ((fps = fopen("SAVE_JOGO", "w")) == NULL)
        {
            apresentaMensagem("\n\nO arquivo SAVE_JOGO não pode ser aberto para cadastrar\n\n");
            return;
        }

        // Gravando o array de peças no arquivo SAVE_DOMINO
        for (i = 0; i < 28; i++)
        {
            if (fwrite(&pecas[i], sizeof(struct domino), 1, fp) != 1)
            {
                apresentaMensagem("\n\nErro na gravação do arquivo SAVE_DOMINO\n\n");
                break;
            }
        }

        // Gravando o array da mesa no arquivo SAVE_MESA
        for (i = 0; i < 28; i++)
        {
            if (fwrite(&mesa[i], sizeof(struct mesa), 1, fpm) != 1)
            {
                apresentaMensagem("\n\nErro na gravação do arquivo SAVE_MESA\n\n");
                break;
            }
        }

        // Gravando a situação do jogo no arquivo SAVE_JOGO
        if (fwrite(&sitJogo, sizeof(struct Jogo), 1, fps) != 1)
            apresentaMensagem("\n\nErro na gravação do arquivo SAVE_JOGO\n\n");

        fclose(fp);
        fclose(fpm);
        fclose(fps);
        apresentaMensagem("\n\nGravados os arquivos SAVE_DOMINO, SAVE_MESA e SAVE_JOGO\n\n");
    }
}

void recuperaCadastro()
{
    int i;
    FILE *fp;
    FILE *fpm;
    FILE *fps;

    if ((fp = fopen("SAVE_DOMINO", "r")) == NULL)
    {
        apresentaMensagem("\n\nO arquivo SAVE_DOMINO não pode ser aberto\n\n");
        return;
    }

    if ((fpm = fopen("SAVE_MESA", "r")) == NULL)
    {
        apresentaMensagem("\n\nO arquivo SAVE_MESA não pode ser aberto\n\n");
        return;
    }

    if ((fps = fopen("SAVE_JOGO", "r")) == NULL)
    {
        apresentaMensagem("\n\nO arquivo SAVE_JOGO não pode ser aberto\n\n");
        return;
    }

    // Lendo o array de peças do arquivo SAVE_DOMINO
    for (i = 0; i < 28; i++)
    {
        if (fread(&pecas[i], sizeof(struct domino), 1, fp) != 1)
        {
            apresentaMensagem("\n\nErro na leitura do arquivo SAVE_DOMINO\n\n");
            break;
        }
    }

    // Lendo o array da mesa do arquivo SAVE_MESA
    for (i = 0; i < 28; i++)
    {
        if (fread(&mesa[i], sizeof(struct mesa), 1, fpm) != 1)
        {
            apresentaMensagem("\n\nErro na leitura do arquivo SAVE_MESA\n\n");
            break;
        }
    }

    // Lendo a situação do jogo do arquivo SAVE_JOGO
    if (fread(&sitJogo, sizeof(struct Jogo), 1, fps) != 1)
        apresentaMensagem("\n\nErro na leitura do arquivo SAVE_JOGO\n\n");

    fclose(fp);
    fclose(fpm);
    fclose(fps);

    // Atualizando variáveis globais com os dados do arquivo
    qtmesa = sitJogo.qtmesaJogo;
    jvez = sitJogo.jogadorJogo;
    computadorJoga = sitJogo.jogadorComp;
    mesaD = sitJogo.mesaDJogo;
    mesaE = sitJogo.mesaEJogo;
}

bool testaj(int es)
{
    bool valida = true;
    if (es == -1)
    {
        valida = false;
    }
    return valida;
}

bool testaPeca()
{
    bool certo = false;
    if (pecas[nj].lado1 == mesaD || pecas[nj].lado1 == mesaE || pecas[nj].lado2 == mesaD || pecas[nj].lado2 == mesaE)
        certo = true;
    return certo;
}

void jogadaComputador()
{

    bool jogou = false; // Variável para verificar se o computador conseguiu jogar

    if (temPecasJogaveis('2')) // Verifica se o computador pode jogar
    {
        for (int i = 0; i < 28; i++) // Percorre todas as peças
        {
            if (pecas[i].status == '2') // Verifica se a peça pertence ao computador
            {
                // Verifica se a peça pode ser jogada à direita
                if (pecas[i].lado1 == mesaD || pecas[i].lado2 == mesaD)
                {
                    carregamesaD(i);
                    jogadorJogou(); // Atualiza o estado após a jogada
                    jogou = true;
                    break;
                }
                // Verifica se a peça pode ser jogada à esquerda
                else if (pecas[i].lado1 == mesaE || pecas[i].lado2 == mesaE)
                {
                    carregamesaE(i);
                    jogadorJogou();
                    jogou = true;
                    break;
                }
            }
        }
    }

    // Caso o computador não tenha conseguido jogar, ele compra uma peça
    if (!jogou)
    {
        if (!depositoVazio()) // Verifica se ainda há peças no depósito
        {
            comprarPeca('2');   // Computador compra uma peça
            jogadaComputador(); // Tenta jogar novamente após a compra
        }
        else
        {
            alternarTurno(); // Se não pode comprar, passa o turno
        }
    }
}
