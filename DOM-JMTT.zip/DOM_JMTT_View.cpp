// DOM_JMTT_View.cpp - Projeto Domino - Etapa 6
// 18/08/2024 - Grupo: JMTT
// Joao Gabriel Guedes Vianna
// Matheus Giampaoli Silva
// Thomas Ki Sun Lee
// Tulio Goncalves Vieira

#include "DOM_JMTT_View.h"

void fMostrar() // funcao que mostra as pecas, embaralhadas ou nao
{
	for (int i = 0; i <= 27; i++)
	{
		printf("[%d|%d] ", pecas[i].lado1, pecas[i].lado2);
	}
}

int fMenuInicio() // menu de opcoes antes do jogo ser iniciado
{
	printf("\n\nJogo de Domino (PUC-SP)");
	printf("\n1) Iniciar Jogo (2 jogadores)");
	printf("\n2) Iniciar Jogo (contra o computador)");
	printf("\n3) Retomar Jogo interrompido");
	printf("\n4) Regras do Jogo");
	printf("\n5) Salvar Jogo");
	printf("\n6) Carregar Jogo");
	printf("\n0) Sair do programa");
	printf("\nOpcao selecionada: ");
	scanf("%d", &op);
	return op;
}

void regrasJogo()
{
	printf("\n\nRegras:\n\n");
	printf("O primeiro jogador e aquele que possui a peca com maiores numeros e lados iguais.\n");
	printf("Caso nenhum dos jogadores possua pecas de lados iguais, comeca quem tiver o maior valor da soma dos dois lados.\n");
	printf("Os jogadores podem comprar quantas pecas quiserem antes de cada jogada, desde que elas estejam disponiveis.\n");
	printf("O objetivo do jogo para cada jogador e acabar com suas pecas, as colocando nas extremidades da mesa.\n");
	printf("As pecas so podem ser colocada sobre a mesa caso uma de suas extremidades seja correspondente a das pecas na mesa.\n");
	printf("Caso um jogador nao possua pecas que podem ser jogadas, ele devera comprar ate conseguir uma peca valida, ou acabar as\n");
	printf("pecas disponiveis, caso as pecas disponiveis acabem, o turno e passado para o proximo jogador.\n");
	printf("O jogo acaba quando um jogador 'bate'(coloca sua ultima peca na mesa), ou nenhum jogador consegue jogar e nao ha mais\n");
	printf("pecas disponives, nesse caso, ganha o jogador que tiver menos pecas.\n\n\n");
}

int fMenuJogada() // menu apos o jogo ter sido iniciado esse e o menu de acoes possiveis
{
	printf("\nJ) Jogar (possiveis %d ou %d)", mesaE, mesaD); // descobrir como faz pra mostrar as extremidades da mesa aq
	printf("\nC) Comprar");
	printf("\nP) Passar");
	printf("\nS) Sair (interromper o jogo)");
	printf("\nOpcao: ");

	scanf(" %c", &jog);

	return jog;
}

void mostrarMesa()
{
	printf("=============\n");
	printf("MESA:  ");
	for (int i = 0, k = 0; i < 28; i++)
	{
		if (pecas[i].status == 'M')
		{
			printf("[%d|%d] ", mesa[k].ladoE, mesa[k].ladoD);
			k++;
		}
	}
	printf("\n=============\n");
}

void apresentaMensagem(char mens[100])
{
	printf("%s\n", mens);
}

void apresentaPeca(char jogador)
{
	char letra = 96;

	if (jogador == '1')
	{
		printf("Pecas do jogador 1: ");
		for (int i = 0; i < 28; i++)
		{
			if (pecas[i].status == '1')
			{
				letra++;

				printf("%c.[%d|%d] ", letra, pecas[i].lado1, pecas[i].lado2);
			}
		}
	}

	if (jogador == '2')
	{
		printf("Pecas do jogador 2: ");
		for (int i = 0; i < 28; i++)
		{
			if (pecas[i].status == '2')
			{
				letra++;

				printf("%c.[%d|%d] ", letra, pecas[i].lado1, pecas[i].lado2);
			}
		}
	}
}

void escolherPeca(char jogador)
{
	char pecaEscolhida;
	printf("\nEscolha uma peca para jogar: ");
	scanf(" %c", &pecaEscolhida);

	// Converte a letra da peça escolhida no índice relativo (a = 0, b = 1, ..., m = 12, ...)
	indiceRelativo = pecaEscolhida - 'a';
}

void jogadorJogou()
{
	if (qtmesa > 1)
	{
		if (jvez == '2')
			printf("\nJogador 1 jogou\n\n");
		else if (computadorJoga)
		{
			printf("\nComputador jogou\n\n");
		}
		else
			printf("\nJogador 2 jogou\n\n");
	}
}

void quemPrimeiraJogada()
{

	if (jvez == '1')
		printf("\nA primeira jogada foi do jogador 1\n\n");
	else if (computadorJoga)
	{
		printf("\nA primeira jogada foi do computador\n\n");
	}
	else
		printf("\nA primeira jogada foi do jogador 2\n\n");
}

int qualLado()
{
	char escolha;   // que lado o jogador quer jogar caso possa jogar dos dois
	printf("\nEscolha o lado para jogar a peca (E = Esquerda, D = Direita): ");
        scanf(" %c", &escolha);
	return escolha;
}