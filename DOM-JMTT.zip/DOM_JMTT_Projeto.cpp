//DOM_JMTT_Projeto.cpp - Projeto Domino - Etapa 6
//18/08/2024 - Grupo: JMTT
//Joao Gabriel Guedes Vianna
//Matheus Giampaoli Silva
//Thomas Ki Sun Lee
//Tulio Goncalves Vieira

#include "DOM_JMTT_Model.cpp"		//inclui os arquivos que possuem
#include "DOM_JMTT_Controller.cpp"	//as funcoes para que o jogo funcione

int main()
{
	fNumerar();
	jogo();
}