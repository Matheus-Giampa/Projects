// DOM_JMTT_Model.cpp - Projeto Domino - Etapa 6
// 18/08/2024 - Grupo: JMTT
// Joao Gabriel Guedes Vianna
// Matheus Giampaoli Silva
// Thomas Ki Sun Lee
// Tulio Goncalves Vieira

#include "DOM_JMTT_Model.h"

typedef struct domino // dados que cada peca possui
{
	char status; // D = disponivel, 1 = com o jogador 1, 2 = com o jogador 2, M = sobre a mesa
	int lado1;
	int lado2;

} tipopeca;

struct mesa // estrutura da mesa
{
	int ladoE;
	int ladoD;

}mesa[28];

// o array dos jogadores e de 21 por que, no pior dos casos,
// um dos jogadores pode ter 21 pecas no maximo
tipopeca pecas[28], pecaaux, p1[21], p2[21]; // variaveis globais

struct Jogo
{
	int qtmesaJogo;	  // qtd.de pecas na mesa
	char jogadorJogo; // jogador atual
	bool jogadorComp;  // 2 = o computador nao o jogador 2
	int mesaDJogo;	  // extremidade direita da mesa
	int mesaEJogo;	  // extremidade esquerda da mesa

} sitJogo; // situação do jogo

void fNumerar() // funcao que inicia as pecas, colocando as 28 diferentes combinacoes de numeros
{
	int vet = 0;

	for (int i = 0; i <= 6; i++)
	{
		for (int j = i; j <= 6; j++)
		{
			pecas[vet].lado1 = i;
			pecas[vet].lado2 = j;
			pecas[vet].status = 'D';
			vet++;
		}
	}
}
