// DOM_JMTT_Model.h - Projeto Domino - Etapa 6
// 18/08/2024 - Grupo: JMTT
// Joao Gabriel Guedes Vianna
// Matheus Giampaoli Silva
// Thomas Ki Sun Lee
// Tulio Goncalves Vieira

void fNumerar();

int op, mesaE, mesaD; // variaveis globais
char jvez, jog;
int qtmesa; // variavel para saber a quantidade de pecas na mesa
int passa;
int nj; // indice geral
int indiceRelativo;
int vitoria = 0; // verifica se tem um vencedor 0 = nao 1 = sim
int temJogo = 0; // verifica se ha um jogo a ser retomado
bool computadorJoga = false; // Indica se o jogador 2 é o computador

typedef int booleano;
#define FALSE 0
#define TRUE 1