// DOM_JMTT_View.h - Projeto Domino - Etapa 6
// 18/08/2024 - Grupo: JMTT
// Joao Gabriel Guedes Vianna
// Matheus Giampaoli Silva
// Thomas Ki Sun Lee
// Tulio Goncalves Vieira

int fMenuInicio();
void fMostrar();
void regrasJogo();
int fMenuJogada();
void apresentaMensagem(char mens[100]);
void apresentaPeca(char jogador);
void escolherPeca(char jogador);
void jogadorJogou();
void quemPrimeiraJogada();
int qualLado();